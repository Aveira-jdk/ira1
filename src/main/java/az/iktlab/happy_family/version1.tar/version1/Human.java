package az.iktlab.happy_family.version1;

import java.util.Arrays;

class Human {
    public String name;
    public String surname;
    public int year;
    public int iq;
    public Pet pet;
    public Human father;
    public Human mother;
    public String[][] schedule;

    public Human(String name, String surname, int year, int iq) {
        this.name = name;
        this.surname = surname;
        this.year = year;
        this.iq = iq;
    }

    public Human(String name, String surname, int year, Human father, Human mother, Pet pet, int iq) {
        this.name = name;
        this.surname = surname;
        this.year = year;
        this.father = father;
        this.mother = mother;
        this.pet = pet;
        this.iq = iq;
    }

    public Human(String name, String surname, int year, Pet cat, int iq) {
    }


    public void greetPet() {
        System.out.printf("Hello, %s\n", pet.nickname);
    }

    public void describePet() {
        String slyness = (pet.trickLevel >= 50) ? "very sly" : "almost not sly";
        System.out.printf("I have a %s, he is %s years old, he is %s\n", pet.species, pet.age, slyness);
    }

//    @Override
//    public String toString() {
//        return "Human{name='" + name + "', surname='" + surname + "', year=" + year +
//                ", iq=" + iq + ", mother=" + mother.name + " " + mother.surname +
//                ", father=" + father.name + " " + father.surname + ", pet=" + pet + "}";
//    }


    @Override
    public String toString() {
        return "Human{" +
                "name='" + name + '\'' +
                ", surname='" + surname + '\'' +
                ", year=" + year +
                ", iq=" + iq +
                ", pet=" + pet +
                ", father=" + father +
                ", mother=" + mother +
                '}';
    }
}
